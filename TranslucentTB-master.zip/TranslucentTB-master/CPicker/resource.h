//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DLL.rc
//
#define IDD_COLORPICKER                 156
#define IDC_COLOR                       1034
#define IDC_COLOR2                      1035
#define IDC_R                           1036
#define IDC_G                           1037
#define IDC_B                           1038
#define IDC_RED                         1039
#define IDC_GREEN                       1040
#define IDC_BLUE                        1041
#define IDC_H                           1042
#define IDC_S                           1043
#define IDC_V                           1044
#define IDC_HUE                         1045
#define IDC_SATURATION                  1046
#define IDC_VALUE                       1047
#define IDC_COLORS                      1048
#define IDC_ALPHA                       1049
#define IDC_ALPHASLIDE                  1050
#define IDC_OLDCOLOR                    1051
#define IDB_OK                          1067
#define IDB_CANCEL                      1068
#define IDC_HEXCOL                      1072
#define IDC_RSLIDER                     1076
#define IDC_GSLIDER                     1077
#define IDC_BSLIDER                     1078
#define IDC_ASLIDER                     1079
#define IDC_HSLIDER                     1080
#define IDC_SSLIDER                     1081
#define IDC_VSLIDER                     1082
#define IDC_HEXSLIDER                   1083

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        183
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1084
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
