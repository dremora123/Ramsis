[ ] I have checked the issue tracker if my question or bug has already been fixed or answered in another (possibly closed) issue.

 - TranslucentTB version: <!-- The current version of TranslucentTB you're using. Open the properties of the TranslucentTB.exe file and look at the details tab to find this out. -->
 - Windows build number: <!-- You can find this by opening winver.exe and checking the number to the right of "OS Build" -->
 - Steps to reproduce: <!-- What you do that triggers the problem -->
 - Expected results: <!-- What should happen -->
 - Actual results: <!-- What happens instead -->
 - Other: <!-- Other things that you feel could help in diagnosing the problem -->